package com.JSPPracrice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tata.ams.util.DBUtil;

public class trash {
	public static Connection getConnection() throws SQLException, ClassNotFoundException {
	    final String URL = "jdbc:mysql://localhost:3306/kaveri"; // Corrected JDBC URL
	    final String USER = "root";
	    final String PASSWORD = "reposeful";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load the MySQL JDBC driver class
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("MySQL JDBC driver not found", e);
        }

        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Connection con = DBUtil.getConnection();
		PreparedStatement ps = con.prepareStatement("SELECT login_id FROM login_table WHERE login_id = ? AND password = ?");
            ps.setInt(1, 1);
            ps.setString(2, "abcd");
            ResultSet rs = ps.executeQuery();
            if (rs.next())
            System.out.println("Connected");	
		
	}
	
}
