package com.JSPPracrice;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class AddTwoNumbers extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
        int i = Integer.parseInt(req.getParameter("num1"));
        int j = Integer.parseInt(req.getParameter("num2"));
        int result = i + j;

        res.setContentType("text/html");
//        PrintWriter out = res.getWriter();
//        out.println("Result is : " + result);
        
        req.setAttribute("res", result);
        
        
//        To connect one page with another  
        RequestDispatcher rd = req.getRequestDispatcher("sq");
        rd.forward(req, res);
        
    }
}
